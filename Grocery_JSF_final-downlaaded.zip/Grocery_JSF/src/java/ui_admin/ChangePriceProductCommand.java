package ui_admin;

///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package product_ui;
//
//import dto.Product;
//import manager.ProductManager;
//import bean.ProductBean;
//
///**
// *
// * @author ezequ
// */
//public class ChangePriceProductCommand implements Command
//{
//
//    private final ProductManager productMgr = new ProductManager();
//    private   Product product;
//    
//    public ChangePriceProductCommand(double price, Product pr)
//    {
//        
//        this.product = pr;
//        t
//    }
//
//    @Override
//    public Object execute()
//    {
//        return productMgr.changePriceProduct(double price
//        , Product pr
//    
//
//);
//    }
//    
//}
