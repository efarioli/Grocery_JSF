package ui_admin;

/**
 *
 * @author gdm1
 */
public interface Command
{
    Object execute();
}
